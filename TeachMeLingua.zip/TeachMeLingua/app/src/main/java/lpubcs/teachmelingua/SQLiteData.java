package lpubcs.teachmelingua;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SQLiteData extends SQLiteOpenHelper {

    public static final String DBFILE = "teachmelingua.db";

    public static final String TABLE_TUTORIAL = "Tutorial";

    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_LANGUAGE = "Language";
    public static final String COLUMN_CATEGORY = "Category";
    public static final String COLUMN_LESSON = "Lesson";
    public static final String COLUMN_PRONOUNCE= "Pronounce";
    public static final String COLUMN_MEANING = "Meaning";

    public SQLiteData(Context context) {
        super(context, "//" +  new File(context.getFilesDir(),DBFILE), null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        db.execSQL("CREATE TABLE " + TABLE_TUTORIAL + " ("
//                + COLUMN_ID + " INTEGER PRIMARY KEY NOT NULL, "
//                + COLUMN_LANGUAGE + " TEXT, "
//                + COLUMN_CATEGORY + " TEXT, "
//                + COLUMN_LESSON + " TEXT, "
//                + COLUMN_PRONOUNCE + " TEXT, "
//                + COLUMN_MEANING + " TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TUTORIAL);
        onCreate(db);
    }

    public boolean newLesson(String language, String category, String lesson, String pronounce, String meaning) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_LANGUAGE, language);
        contentValues.put(COLUMN_CATEGORY, category);
        contentValues.put(COLUMN_LESSON, lesson);
        contentValues.put(COLUMN_PRONOUNCE, pronounce);
        contentValues.put(COLUMN_MEANING, meaning);
        db.insert(TABLE_TUTORIAL, null, contentValues);
        return true;
    }

    public List<String> getLessonList(String language, String category) {
        List<String> rowsFound = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor rs = db.rawQuery("SELECT * FROM " + TABLE_TUTORIAL + " WHERE " + COLUMN_LANGUAGE + "='" + language + "' AND " + COLUMN_CATEGORY + "='" + category +"'", null );
        if (rs.getCount() > 0) {
            if (rs.moveToFirst()) {
                do {
                    rowsFound.add(rs.getString(3));
                } while (rs.moveToNext());
            }
        }
        return rowsFound;
    }

    public List<String> getLessonDetails(String lesson) {
        List<String> rowsFound = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor rs = db.rawQuery("SELECT * FROM " + TABLE_TUTORIAL + " WHERE " + COLUMN_LESSON + "='" + lesson + "'", null);
        if (rs.getCount() > 0) {
            if (rs.moveToFirst()) {
                do {
                    rowsFound.add(rs.getString(0));
                    rowsFound.add(rs.getString(1));
                    rowsFound.add(rs.getString(2));
                    rowsFound.add(rs.getString(3));
                    rowsFound.add(rs.getString(4));
                    rowsFound.add(rs.getString(5));
                } while (rs.moveToNext());
            }
        }
        return rowsFound;
    }

    public List<String> getMeaningList(String language, String category) {
        List<String> rowsFound = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor rs = db.rawQuery("SELECT " + COLUMN_MEANING + " FROM " + TABLE_TUTORIAL + " WHERE " + COLUMN_LANGUAGE + "='" + language + "' AND " + COLUMN_CATEGORY + "='" + category +"'", null );
        if (rs.getCount() > 0) {
            if (rs.moveToFirst()) {
                do {
                    rowsFound.add(rs.getString(0));
                } while (rs.moveToNext());
            }
        }
        return rowsFound;
    }

    public void deleteData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_TUTORIAL +" WHERE " + COLUMN_ID + " >=11" + "AND " + COLUMN_ID + " <=45");
        db.close();
    }
}