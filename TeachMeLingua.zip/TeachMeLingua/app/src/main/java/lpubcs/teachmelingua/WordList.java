package lpubcs.teachmelingua;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WordList extends AppCompatActivity {

    TextToSpeech tts;
    Locale SPANISH = new Locale("spa", "MEX");

    String language="EN";
    String category="W";
    ArrayList<String> wordsToPronounce;
    ArrayList<String> wordsPronounciations;
    ArrayList<String> wordsMeanings;

    ArrayAdapter<String> arrayAdapter;

    String selectedWord = "";
    String selectedMeaning = "";
    String selectedPronounciation = "";
    String spokenWord = "";

    SQLiteData db;

    List<String> rowLessons;
    List<String> rowLessonDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word_list);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        TextView tvCaption = findViewById(R.id.tvCaption);

        ListView listWords = findViewById(R.id.listWords);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            language = extras.getString("language");
            category = extras.getString("category");

        }

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    if(language.equalsIgnoreCase("en")){
                        tts.setLanguage(Locale.ENGLISH);
                    }
                    else if(language.equalsIgnoreCase("fr")){
                        tts.setLanguage(Locale.FRENCH);
                    }
                    else if(language.equalsIgnoreCase("ch")){
                        tts.setLanguage(Locale.CHINESE);
                    }
                    else if(language.equalsIgnoreCase("sp")){
                        tts.setLanguage(SPANISH);
                    }                }
            }
        });

        wordsToPronounce = new ArrayList<String>();
        wordsPronounciations = new ArrayList<String>();
        wordsMeanings = new ArrayList<String>();

        db = new SQLiteData(this);

        rowLessons = db.getLessonList(language.toUpperCase(),category.toUpperCase());

        if(rowLessons.size()>0){
            for(int i =0;i<rowLessons.size();i++){
                rowLessonDetails = db.getLessonDetails(rowLessons.get(i));

                if(rowLessonDetails.size()>0){
                    wordsToPronounce.add(rowLessonDetails.get(3));
                    wordsPronounciations.add(rowLessonDetails.get(4));
                    wordsMeanings.add(rowLessonDetails.get(5));
                }
            }
        }

        if(language.equalsIgnoreCase("en")){
            this.setTitle("English");
            if(category.equalsIgnoreCase("w")){
                tvCaption.setText("Words");
            }
            else if(category.equalsIgnoreCase("p")){
                tvCaption.setText("Phrases");
            }
            else if(category.equalsIgnoreCase("s")){
                tvCaption.setText("Sentences");
            }
        }
        else if(language.equalsIgnoreCase("fr")){
            this.setTitle("French");
            if(category.equalsIgnoreCase("w")){
                tvCaption.setText("Words");
            }
            else if(category.equalsIgnoreCase("p")){
                tvCaption.setText("Phrases");
            }
            else if(category.equalsIgnoreCase("s")){
                tvCaption.setText("Sentences");
            }
        }
        else if(language.equalsIgnoreCase("ch")){
            this.setTitle("Mandarin");
            if(category.equalsIgnoreCase("w")){
                tvCaption.setText("Words");
            }
            else if(category.equalsIgnoreCase("p")){
                tvCaption.setText("Phrases");
            }
            if(category.equalsIgnoreCase("s")){
                tvCaption.setText("Sentences");
            }

        }
        else if(language.equalsIgnoreCase("sp")){
            this.setTitle("Spanish");
            if(category.equalsIgnoreCase("w")){
                tvCaption.setText("Words");
            }
            else if(category.equalsIgnoreCase("p")){
                tvCaption.setText("Phrases");
            }
            else if(category.equalsIgnoreCase("s")){
                tvCaption.setText("Sentences");
            }
        }

        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, wordsToPronounce);

        listWords.setAdapter(arrayAdapter);

        listWords.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> arg0, View v, int position, long arg3) {

                selectedWord = wordsToPronounce.get(position);
                selectedPronounciation = wordsPronounciations.get(position);
                selectedMeaning = wordsMeanings.get(position);

                tts.speak(selectedWord, TextToSpeech.QUEUE_FLUSH, null);

                Intent intent = new Intent(WordList.this, Basics.class);
                intent.putExtra("language",language);
                intent.putExtra("category",category);
                intent.putExtra("keyword",selectedWord);
                intent.putExtra("pronounce", selectedPronounciation);
                intent.putExtra("meaning",selectedMeaning);
                startActivity(intent);
            }
        });
    }

    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

}