package lpubcs.teachmelingua;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class PageFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.pagefragment, container, false);

        ImageView imageview_photo = v.findViewById(R.id.imageview_photo);
        TextView textview_name = v.findViewById(R.id.textview_name);
        TextView textview_address = v.findViewById(R.id.textview_address);
        TextView textview_contactno = v.findViewById(R.id.textview_contactno);
        TextView textview_email = v.findViewById(R.id.textview_email);


        if(getArguments().getString("msg")=="0"){

            imageview_photo.setImageResource(R.drawable.angelene);
            textview_name.setText("Angelene P. Dayandayan");
            textview_address.setText("Malibu Tuy Batangas");
            textview_contactno.setText("09067332564");
            textview_email.setText("dayandayanangelene52@gmail.com");
        }
        else if(getArguments().getString("msg")=="1"){
            imageview_photo.setImageResource(R.drawable.keiziahh);
            textview_name.setText("Kylie Keiziah H. De Castro");
            textview_address.setText("Inicbulan, Bauan, Batangas");
            textview_contactno.setText("09217367384");
            textview_email.setText("kyliekeiziahdecastro@gmail.com");
        }
        else if(getArguments().getString("msg")=="2"){
            imageview_photo.setImageResource(R.drawable.liitt);
            textview_name.setText("Rica Mae B. Manalo");
            textview_address.setText("#349 Sitio Riverside Bukal Sur, Candelaria Quezon");
            textview_contactno.setText("09459917762");
            textview_email.setText("Manaloricamaeb@gmail.com");
        }
        else if(getArguments().getString("msg")=="3"){
            imageview_photo.setImageResource(R.drawable.quesadaa);
            textview_name.setText("Carlo Luis M. Quesada");
            textview_address.setText("Alangilan, Batangas City");
            textview_contactno.setText("09155839783");
            textview_email.setText("quesadacarlo0@gmail.com");
        }

        return v;
    }

    public static PageFragment newInstance(String text) {

        PageFragment f = new PageFragment();
        Bundle b = new Bundle();
        b.putString("msg", text);

        f.setArguments(b);

        return f;
    }

}