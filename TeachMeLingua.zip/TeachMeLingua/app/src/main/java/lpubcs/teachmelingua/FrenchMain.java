package lpubcs.teachmelingua;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class FrenchMain extends AppCompatActivity {

    TextToSpeech tts;

    String speechText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_french);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        this.setTitle("French");

        Button btnWords= findViewById(R.id.btnWords);
        Button btnPhrases = findViewById(R.id.btnPhrases);
        Button btnSentences = findViewById(R.id.btnSentences);


        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.ENGLISH);
                }
            }
        });


        btnWords.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                MediaPlayer mediaPlayer;
                mediaPlayer = MediaPlayer.create(FrenchMain.this, R.raw.notify);
                mediaPlayer.start();

                Intent intent = new Intent(FrenchMain.this, WordList.class);
                intent.putExtra("language","FR");
                intent.putExtra("category","W");
                startActivity(intent);
            }
        });

        btnPhrases.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                MediaPlayer mediaPlayer;
                mediaPlayer = MediaPlayer.create(FrenchMain.this, R.raw.notify);
                mediaPlayer.start();

                Intent intent = new Intent(FrenchMain.this, WordList.class);
                intent.putExtra("language","FR");
                intent.putExtra("category","P");
                startActivity(intent);
            }
        });

        btnSentences.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                MediaPlayer mediaPlayer;
                mediaPlayer = MediaPlayer.create(FrenchMain.this, R.raw.notify);
                mediaPlayer.start();

                Intent intent = new Intent(FrenchMain.this, WordList.class);
                intent.putExtra("language","FR");
                intent.putExtra("category","S");
                startActivity(intent);
            }
        });

    }

    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 100: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    speechText = result.get(0).trim();

                } else {

                }
                break;
            }
        }
    }
}