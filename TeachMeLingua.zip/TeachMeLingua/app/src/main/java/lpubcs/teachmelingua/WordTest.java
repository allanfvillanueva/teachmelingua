package lpubcs.teachmelingua;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class WordTest extends AppCompatActivity {

    TextToSpeech tts;
    TextToSpeech tts2;
    Locale SPANISH = new Locale("spa", "MEX");

    String language="1";
    String category="1";

    String keyword ="keyword";
    String meaning="meaning";

    ArrayList<String> wordsChoices;

    ArrayAdapter<String> arrayAdapter;

    String selectedAnswer = "";
    String selectedMeaning = "";
    String selectedPronounciation = "";
    String spokenWord = "";

    SQLiteData db;

    List<String> rowLessons;
    List<String> rowLessonMeanings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wordtest);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        TextView tvCaption = findViewById(R.id.tvCaption);

        ListView listTestChoices = findViewById(R.id.listTestChoices);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            language = extras.getString("language");
            category = extras.getString("category");
            keyword = extras.getString("keyword");
            meaning = extras.getString("meaning");
        }

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            if (status != TextToSpeech.ERROR) {
                                if(language.equalsIgnoreCase("en")){
                                    tts.setLanguage(Locale.ENGLISH);
                                }
                                else if(language.equalsIgnoreCase("fr")){
                                    tts.setLanguage(Locale.FRENCH);
                                }
                                else if(language.equalsIgnoreCase("ch")){
                                    tts.setLanguage(Locale.CHINESE);
                                }
                                else if(language.equalsIgnoreCase("sp")){
                                    tts.setLanguage(SPANISH);
                                }
                            }
                        }
                    });
                }
            }
        });

        wordsChoices = new ArrayList<String>();

        db = new SQLiteData(this);

        tvCaption.setText("Select the meaning of " + keyword.toUpperCase());
        rowLessons = db.getLessonList(language,category);
        rowLessonMeanings = db.getMeaningList(language,category);

        Collections.shuffle(rowLessonMeanings);

        if(rowLessonMeanings.size()>0){
            for(int i = 0; i< rowLessonMeanings.size(); i++){
                wordsChoices.add(rowLessonMeanings.get(i));
            }
        }

        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, wordsChoices);

        listTestChoices.setAdapter(arrayAdapter);


        listTestChoices.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> arg0, View v, int position, long arg3) {

                selectedAnswer = wordsChoices.get(position);

                tts.setLanguage(Locale.ENGLISH);

                if(meaning.equalsIgnoreCase(selectedAnswer)){
                    tts.speak("Great, you got it.", TextToSpeech.QUEUE_FLUSH, null);
                    if(language.equalsIgnoreCase("en"))
                        tts.speak(keyword + " is " + meaning, TextToSpeech.QUEUE_ADD, null);
                    else
                        tts.speak(" The meaning is " + meaning, TextToSpeech.QUEUE_ADD, null);

                    finish();
                }
                else{
                    tts.speak("Sorry, try another one.", TextToSpeech.QUEUE_FLUSH, null);
                }
            }
        });
    }

    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

}