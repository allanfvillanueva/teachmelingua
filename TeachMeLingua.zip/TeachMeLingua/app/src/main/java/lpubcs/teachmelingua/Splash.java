package lpubcs.teachmelingua;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class Splash extends AppCompatActivity {

    String DBFile = "teachmelingua.db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_splash);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        if(new File("//" + getFilesDir() + "/" + DBFile).exists()==false){
            //Toast.makeText(getApplicationContext(),"File does not exist.",Toast.LENGTH_SHORT).show();
            copyFile(DBFile);
        }
        else{
            //Toast.makeText(getApplicationContext(),"File exists.",Toast.LENGTH_SHORT).show();
        }

        CountDownTimer timer = new CountDownTimer(2000, 500) {

            @Override
            public void onFinish() {
                    Intent intent = new Intent(Splash.this, MainMenu.class);
                    startActivity(intent);
                    finish();
            }

            @Override
            public void onTick(long arg0) {

            }
        };
        timer.start();

    }

    private void copyFile(String filename) {
        AssetManager assetManager = this.getAssets();

        InputStream in = null;
        OutputStream out = null;
        try {
            in = assetManager.open(filename);
            String newFileName = getFilesDir().getAbsolutePath() + "/" + filename;
            out = new FileOutputStream(newFileName);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;
            out.flush();
            out.close();
            out = null;
        } catch (Exception e) {
            Log.e("copyFile", e.getMessage());
        }

    }

}
