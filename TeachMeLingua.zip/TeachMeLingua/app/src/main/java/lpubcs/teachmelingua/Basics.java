package lpubcs.teachmelingua;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class Basics extends AppCompatActivity {

    TextToSpeech tts;
    Locale SPANISH = new Locale("spa", "MEX");

    String keyword ="";
    String pronounce="";
    String meaning="";


    String language="en";
    String category="w";

    ArrayList<String> listMeanings;
    ArrayAdapter<String> arrayAdapter;

    String selectedWord = "";
    String spokenWord = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basics);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        TextView tvKeyWord = findViewById(R.id.tvKeyWord);
        TextView tvMeaning = findViewById(R.id.tvMeaning);

        ImageView ivPlayWord = findViewById(R.id.ivPlayWord);
        ImageView ivTestWord = findViewById(R.id.ivTestWord);

        final Button bnContinue = findViewById(R.id.bnContinue);

//        ListView listChoices = findViewById(R.id.lvChoices);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            language = extras.getString("language");
            category = extras.getString("category");
            keyword = extras.getString("keyword");
            pronounce = extras.getString("pronounce");
            meaning = extras.getString("meaning");
        }

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    //tts.setLanguage(Locale.ENGLISH);
                    //tts.speak("Choose a word or a phrase.", TextToSpeech.QUEUE_FLUSH, null);
                }
            }
        });

        tvKeyWord.setText(keyword);
        tvMeaning.setText(meaning);


        listMeanings = new ArrayList<String>();

        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listMeanings);


        if(language.equalsIgnoreCase("en")){
            this.setTitle("English");
            //bnContinue.setText("Close");
            ivTestWord.setVisibility(View.VISIBLE);
        }
        else if(language.equalsIgnoreCase("fr")){
            this.setTitle("French");
            ivTestWord.setVisibility(View.GONE);
        }
        else if(language.equalsIgnoreCase("ch")){
            this.setTitle("Mandarin");
            ivTestWord.setVisibility(View.GONE);
        }
        else if(language.equalsIgnoreCase("sp")){
            this.setTitle("Spanish");
            ivTestWord.setVisibility(View.GONE);
        }

//        listChoices.setAdapter(arrayAdapter);

        ivPlayWord.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(language.equalsIgnoreCase("en")){
                    tts.setLanguage(Locale.ENGLISH);
                }
                else if(language.equalsIgnoreCase("fr")){
                    tts.setLanguage(Locale.FRENCH);
                }
                else if(language.equalsIgnoreCase("ch")){
                    tts.setLanguage(Locale.CHINESE);
                }
                else if(language.equalsIgnoreCase("sp")){
                    tts.setLanguage(SPANISH);
                }

                tts.speak(keyword, TextToSpeech.QUEUE_FLUSH, null);

            }
        });

        ivTestWord.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                //intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

                if(language.equalsIgnoreCase("en")){
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH);
                }
                else if(language.equalsIgnoreCase("fr")){
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.FRENCH);
                }
                else if(language.equalsIgnoreCase("ch")){
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.CHINESE);
                }
                else if(language.equalsIgnoreCase("sp")){
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, SPANISH);
                }


                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak out '" + keyword.toUpperCase() + "'");

                try {
                    startActivityForResult(intent, 100);
                } catch (ActivityNotFoundException a) {

                }

            }
        });

        bnContinue.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(bnContinue.getText().toString().equalsIgnoreCase("close")){
                    finish();
                }
                else{
                    Intent intent = new Intent(Basics.this, WordTest.class);
                    intent.putExtra("language",language);
                    intent.putExtra("category",category);
                    intent.putExtra("keyword",keyword);
                    intent.putExtra("pronounce",pronounce);
                    intent.putExtra("meaning",meaning);

                    String key="";
                    if(category.equalsIgnoreCase("w"))
                        key="word";
                    else if(category.equalsIgnoreCase("p"))
                        key="phrase";
                    else if(category.equalsIgnoreCase("s"))
                        key="sentence";

                    tts.setLanguage(Locale.ENGLISH);

                    tts.speak("Select the correct meaning of the " + key, TextToSpeech.QUEUE_FLUSH, null);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 100: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    spokenWord = result.get(0).trim();

                    tts.setLanguage(Locale.ENGLISH);
                    if (!spokenWord.equalsIgnoreCase(keyword))
                        tts.speak("Sorry!", TextToSpeech.QUEUE_FLUSH, null);
                    else
                        tts.speak("Great!", TextToSpeech.QUEUE_FLUSH, null);

                }
                break;
            }
        }
    }
}